package com.stoj.vpn

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var selectedCountry = "🇩🇪  Германия"
    private var demoOn = false
    private lateinit var status: TextView
    private lateinit var connect: Button
    private lateinit var countryLabel: TextView
    private val bg = Color.rgb(8, 13, 27)
    private val panel = Color.rgb(17, 26, 46)
    private val blue = Color.rgb(56, 189, 248)
    private val white = Color.rgb(248, 250, 252)
    private val muted = Color.rgb(148, 163, 184)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 38, 24, 24)
            setBackgroundColor(bg)
        }
        fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
                if (bold) setTypeface(null, Typeface.BOLD)
                setPadding(8, 12, 8, 12)
            }

        page.addView(label("⬡  S-TOJ VPN", 28f, blue, true))
        page.addView(label("PRIVATE CONNECTION", 12f, muted))
        status = label("Соединение не установлено", 15f, muted)
        page.addView(status)
        val power = Button(this).apply {
            text = "⏻"
            textSize = 34f
            setTextColor(white)
            setBackgroundColor(Color.rgb(22, 46, 75))
            setOnClickListener { toggleDemo() }
        }
        page.addView(power, LinearLayout.LayoutParams(180, 110).apply {
            topMargin = 20; bottomMargin = 12
        })
        page.addView(label("Защити соединение", 21f, white, true))
        page.addView(label("Выбери страну ниже", 13f, muted))
        connect = Button(this).apply {
            text = "Подключиться"
            textSize = 16f
            setTextColor(white)
            setBackgroundColor(Color.rgb(2, 132, 199))
            setOnClickListener { toggleDemo() }
        }
        page.addView(connect, LinearLayout.LayoutParams(-1, 56).apply {
            topMargin = 18; bottomMargin = 20
        })
        page.addView(label("ВЫБЕРИ СЕРВЕР", 14f, blue, true))
        countryLabel = label(selectedCountry, 18f, white, true)
        page.addView(countryLabel)
        listOf("🇩🇪  Германия", "🇳🇱  Нидерланды", "🇺🇸  США").forEach { country ->
            val b = Button(this).apply {
                text = country
                textSize = 15f
                setTextColor(white)
                setBackgroundColor(panel)
                setOnClickListener {
                    if (demoOn) {
                        Toast.makeText(this@MainActivity, "Сначала отключи демо", Toast.LENGTH_SHORT).show()
                    } else {
                        selectedCountry = country
                        countryLabel.text = selectedCountry
                    }
                }
            }
            page.addView(b, LinearLayout.LayoutParams(-1, 50).apply { topMargin = 5 })
        }
        page.addView(label(
            "ВНИМАНИЕ: это начальный UI-прототип. Кнопка пока не создаёт VPN-туннель и не меняет IP-адрес.",
            12f, muted
        ))
        setContentView(page)
    }

    private fun toggleDemo() {
        demoOn = !demoOn
        status.text = if (demoOn) "Демо включено · VPN не подключён" else "Соединение не установлено"
        connect.text = if (demoOn) "Отключить демо" else "Подключиться"
        Toast.makeText(
            this,
            if (demoOn) "Демо интерфейса — интернет не защищён VPN" else "Демо отключено",
            Toast.LENGTH_LONG
        ).show()
    }
}
